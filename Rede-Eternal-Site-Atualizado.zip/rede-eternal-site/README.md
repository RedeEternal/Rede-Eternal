# Rede Eternal — site oficial

Site estático responsivo feito com HTML, CSS e JavaScript. Não precisa instalar programas nem contratar hospedagem para publicar no GitHub Pages.

## Publicar no GitHub Pages

1. Entre em https://github.com/ e crie um repositório público chamado `rede-eternal-site`.
2. Dentro do repositório, clique em **Add file → Upload files**.
3. Extraia este ZIP e envie os quatro arquivos: `index.html`, `style.css`, `script.js` e `README.md`.
4. Clique em **Commit changes**.
5. Abra **Settings → Pages**.
6. Em **Build and deployment**, escolha **Deploy from a branch**.
7. Escolha branch `main` e pasta `/(root)`, depois clique em **Save**.
8. Aguarde alguns minutos; o GitHub Pages mostrará o endereço do site.

## Dados configurados

- Minecraft original: `redeeternal.enxada.gg`
- Minecraft pirata: `enx-cirion-43.enx.host:10210`
- Discord oficial: https://discord.gg/Xrd4qj8F6g
- Compras: direcionadas ao Discord oficial. Não há seção de ranks ou loja externa.

## Personalizar

- Conteúdo e links: `index.html`
- Cores e aparência: `style.css`
- Botões de copiar IP e menu mobile: `script.js`

Os dois endereços de Minecraft são apresentados separadamente. Confira se continuam corretos antes de publicar.
